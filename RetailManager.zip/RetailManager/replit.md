# RetailPro - Retail Management System

## Overview

RetailPro is a full-stack retail management application built with React, Express, and PostgreSQL. The system provides comprehensive functionality for managing inventory, customers, sales events, and messaging within a retail environment. It features a modern, responsive interface built with Tailwind CSS and shadcn/ui components.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### July 27, 2025
- **Fixed Event Creation Bug**: Resolved TypeScript validation errors preventing sales event creation
  - Added `apiInsertSalesEventSchema` in shared/schema.ts for proper date string handling
  - Updated server routes to use new schema that converts date strings to Date objects
  - Fixed form submission to send dates as strings instead of Date objects
  - Event creation now works properly through the web interface

- **Database Integration**: Converted application from in-memory storage to PostgreSQL database
  - Created database connection using Neon serverless with Drizzle ORM
  - Replaced MemStorage with DatabaseStorage implementation for all entities
  - Pushed schema to database using `npm run db:push` command
  - All CRUD operations now persist data in PostgreSQL database
  - Verified functionality with API testing - inventory, customers, and events creation working

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for development and production builds
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: React Context for global state, TanStack Query for server state
- **Routing**: Wouter for client-side routing
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ESM modules
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Validation**: Zod for runtime type checking
- **Session Management**: Express sessions with PostgreSQL store

### Database Design
- **ORM**: Drizzle with PostgreSQL dialect
- **Migrations**: Drizzle Kit for schema management
- **Connection**: Neon Database serverless connection

## Key Components

### Core Entities
1. **Users**: Authentication and user management
2. **Inventory Items**: Product catalog with SKU, pricing, and stock management
3. **Customers**: Customer database with contact information and preferences
4. **Sales Events**: Event management for sales campaigns and promotions
5. **Sales**: Transaction records linking customers, items, and events
6. **Messages**: Internal messaging system for customer communication

### Frontend Components
- **Dashboard**: Analytics and overview with charts (Recharts)
- **Inventory Management**: CRUD operations for products with search and filtering
- **Customer Management**: Customer database with search capabilities
- **Sales Events**: Event planning and management interface
- **Messaging**: Communication tools for customer outreach

### Backend Services
- **Storage Interface**: Abstracted data layer for CRUD operations
- **Route Handlers**: RESTful API endpoints for all entities
- **Validation**: Schema validation using Zod
- **Error Handling**: Centralized error management

## Data Flow

1. **Client Requests**: React components make API calls using TanStack Query
2. **API Routes**: Express routes handle requests and validate input data
3. **Business Logic**: Route handlers process requests and interact with storage
4. **Database Operations**: Drizzle ORM manages database queries and transactions
5. **Response**: JSON responses sent back to client with appropriate status codes

### Authentication Flow
- Session-based authentication using Express sessions
- User credentials stored securely with hashed passwords
- Session data persisted in PostgreSQL using connect-pg-simple

## External Dependencies

### Production Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **drizzle-orm & drizzle-zod**: Database ORM and schema validation
- **@tanstack/react-query**: Server state management
- **react-hook-form & @hookform/resolvers**: Form handling and validation
- **wouter**: Lightweight React router
- **date-fns**: Date manipulation utilities
- **recharts**: Chart library for analytics

### UI Dependencies
- **@radix-ui/**: Comprehensive set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant API for components
- **lucide-react**: Icon library

## Deployment Strategy

### Development
- **Vite Dev Server**: Hot module replacement for rapid development
- **Express Server**: API server with middleware for logging and error handling
- **Environment Variables**: Database URL and other configuration via environment

### Production Build
- **Frontend**: Vite builds optimized static assets
- **Backend**: esbuild bundles server code for production
- **Database**: Drizzle migrations ensure schema consistency

### Replit Integration
- **Runtime Error Overlay**: Development error handling
- **Cartographer Plugin**: Enhanced Replit development experience
- **Banner Script**: Development environment indicators

The application follows a traditional three-tier architecture with clear separation between presentation (React), business logic (Express), and data storage (PostgreSQL). The use of TypeScript throughout ensures type safety, while the modular component architecture supports maintainability and scalability.