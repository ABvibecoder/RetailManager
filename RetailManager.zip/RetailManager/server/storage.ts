import { 
  type User, 
  type InsertUser,
  type InventoryItem,
  type InsertInventoryItem,
  type Customer,
  type InsertCustomer,
  type SalesEvent,
  type InsertSalesEvent,
  type Sale,
  type InsertSale,
  type Message,
  type InsertMessage
} from "@shared/schema";


export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Inventory Items
  getInventoryItems(): Promise<InventoryItem[]>;
  getInventoryItem(id: string): Promise<InventoryItem | undefined>;
  createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: string, item: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined>;
  deleteInventoryItem(id: string): Promise<boolean>;
  searchInventoryItems(query: string, category?: string): Promise<InventoryItem[]>;

  // Customers
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: string): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: string, customer: Partial<InsertCustomer>): Promise<Customer | undefined>;
  deleteCustomer(id: string): Promise<boolean>;
  searchCustomers(query: string): Promise<Customer[]>;

  // Sales Events
  getSalesEvents(): Promise<SalesEvent[]>;
  getSalesEvent(id: string): Promise<SalesEvent | undefined>;
  createSalesEvent(event: InsertSalesEvent): Promise<SalesEvent>;
  updateSalesEvent(id: string, event: Partial<InsertSalesEvent>): Promise<SalesEvent | undefined>;
  deleteSalesEvent(id: string): Promise<boolean>;

  // Sales
  getSales(): Promise<Sale[]>;
  getSale(id: string): Promise<Sale | undefined>;
  createSale(sale: InsertSale): Promise<Sale>;
  getSalesByEvent(eventId: string): Promise<Sale[]>;
  getSalesByCustomer(customerId: string): Promise<Sale[]>;

  // Messages
  getMessages(): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;

  // Analytics
  getDashboardStats(): Promise<{
    totalSales: number;
    totalItems: number;
    totalCustomers: number;
    activeEvents: number;
    recentSales: Array<{
      customerName: string;
      itemName: string;
      amount: string;
      time: string;
    }>;
    bestSellers: Array<{
      name: string;
      sold: number;
      revenue: string;
    }>;
    salesData: Array<{ month: string; sales: number }>;
    categoryData: Array<{ category: string; value: number }>;
  }>;
}

import { users, inventoryItems, customers, salesEvents, sales, messages, type User, type InsertUser, type InventoryItem, type InsertInventoryItem, type Customer, type InsertCustomer, type SalesEvent, type InsertSalesEvent, type Sale, type InsertSale, type Message, type InsertMessage } from "@shared/schema";
import { db } from "./db";
import { eq, ilike, and, or, desc, count, sum } from "drizzle-orm";

export class DatabaseStorage implements IStorage {

  // No initialization needed for database storage

  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Inventory Items
  async getInventoryItems(): Promise<InventoryItem[]> {
    return await db.select().from(inventoryItems).orderBy(desc(inventoryItems.createdAt));
  }

  async getInventoryItem(id: string): Promise<InventoryItem | undefined> {
    const [item] = await db.select().from(inventoryItems).where(eq(inventoryItems.id, id));
    return item;
  }

  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    const [newItem] = await db.insert(inventoryItems).values(item).returning();
    return newItem;
  }

  async updateInventoryItem(id: string, updates: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined> {
    const [updatedItem] = await db.update(inventoryItems)
      .set(updates)
      .where(eq(inventoryItems.id, id))
      .returning();
    return updatedItem;
  }

  async deleteInventoryItem(id: string): Promise<boolean> {
    const result = await db.delete(inventoryItems).where(eq(inventoryItems.id, id));
    return result.rowCount > 0;
  }

  async searchInventoryItems(query: string, category?: string): Promise<InventoryItem[]> {
    let dbQuery = db.select().from(inventoryItems);
    
    const conditions = [];
    if (query) {
      conditions.push(
        or(
          ilike(inventoryItems.name, `%${query}%`),
          ilike(inventoryItems.sku, `%${query}%`),
          ilike(inventoryItems.description, `%${query}%`)
        )
      );
    }
    if (category && category !== "All Categories") {
      conditions.push(eq(inventoryItems.category, category));
    }
    
    if (conditions.length > 0) {
      dbQuery = dbQuery.where(and(...conditions));
    }
    
    return await dbQuery.orderBy(desc(inventoryItems.createdAt));
  }

  // Customers
  async getCustomers(): Promise<Customer[]> {
    return await db.select().from(customers).orderBy(desc(customers.createdAt));
  }

  async getCustomer(id: string): Promise<Customer | undefined> {
    const [customer] = await db.select().from(customers).where(eq(customers.id, id));
    return customer;
  }

  async createCustomer(customer: InsertCustomer): Promise<Customer> {
    const [newCustomer] = await db.insert(customers).values(customer).returning();
    return newCustomer;
  }

  async updateCustomer(id: string, updates: Partial<InsertCustomer>): Promise<Customer | undefined> {
    const [updatedCustomer] = await db.update(customers)
      .set(updates)
      .where(eq(customers.id, id))
      .returning();
    return updatedCustomer;
  }

  async deleteCustomer(id: string): Promise<boolean> {
    const result = await db.delete(customers).where(eq(customers.id, id));
    return result.rowCount > 0;
  }

  async searchCustomers(query: string): Promise<Customer[]> {
    if (!query) {
      return await this.getCustomers();
    }
    return await db.select().from(customers).where(
      or(
        ilike(customers.name, `%${query}%`),
        ilike(customers.email, `%${query}%`),
        ilike(customers.phone, `%${query}%`)
      )
    ).orderBy(desc(customers.createdAt));
  }

  // Sales Events
  async getSalesEvents(): Promise<SalesEvent[]> {
    return await db.select().from(salesEvents).orderBy(desc(salesEvents.createdAt));
  }

  async getSalesEvent(id: string): Promise<SalesEvent | undefined> {
    const [event] = await db.select().from(salesEvents).where(eq(salesEvents.id, id));
    return event;
  }

  async createSalesEvent(event: InsertSalesEvent): Promise<SalesEvent> {
    const [newEvent] = await db.insert(salesEvents).values(event).returning();
    return newEvent;
  }

  async updateSalesEvent(id: string, updates: Partial<InsertSalesEvent>): Promise<SalesEvent | undefined> {
    const [updatedEvent] = await db.update(salesEvents)
      .set(updates)
      .where(eq(salesEvents.id, id))
      .returning();
    return updatedEvent;
  }

  async deleteSalesEvent(id: string): Promise<boolean> {
    const result = await db.delete(salesEvents).where(eq(salesEvents.id, id));
    return result.rowCount > 0;
  }

  // Sales
  async getSales(): Promise<Sale[]> {
    return await db.select().from(sales).orderBy(desc(sales.saleDate));
  }

  async getSale(id: string): Promise<Sale | undefined> {
    const [sale] = await db.select().from(sales).where(eq(sales.id, id));
    return sale;
  }

  async createSale(sale: InsertSale): Promise<Sale> {
    const [newSale] = await db.insert(sales).values(sale).returning();
    return newSale;
  }

  async getSalesByEvent(eventId: string): Promise<Sale[]> {
    return await db.select().from(sales).where(eq(sales.eventId, eventId));
  }

  async getSalesByCustomer(customerId: string): Promise<Sale[]> {
    return await db.select().from(sales).where(eq(sales.customerId, customerId));
  }

  // Messages
  async getMessages(): Promise<Message[]> {
    return await db.select().from(messages).orderBy(desc(messages.sentAt));
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }

  // Analytics
  async getDashboardStats() {
    const [salesCount] = await db.select({ count: count() }).from(sales);
    const [itemsCount] = await db.select({ count: count() }).from(inventoryItems);
    const [customersCount] = await db.select({ count: count() }).from(customers);
    const [activeEventsCount] = await db.select({ count: count() }).from(salesEvents).where(eq(salesEvents.status, "active"));
    
    // For now, return mock data for complex analytics until we have actual sales data
    return {
      totalSales: 0,
      totalItems: itemsCount.count,
      totalCustomers: customersCount.count,
      activeEvents: activeEventsCount.count,
      recentSales: [
        { customerName: "John Doe", itemName: "Leather Wallet", amount: "₹3,792", time: "2 hours ago" },
        { customerName: "Sarah Smith", itemName: "Designer Handbag", amount: "₹10,112", time: "4 hours ago" },
        { customerName: "Mike Johnson", itemName: "Sports Shoes", amount: "₹7,582", time: "6 hours ago" },
      ],
      bestSellers: [
        { name: "Premium T-Shirt", sold: 234, revenue: "₹4,92,950" },
        { name: "Designer Jeans", sold: 189, revenue: "₹7,16,678" },
        { name: "Casual Sneakers", sold: 156, revenue: "₹5,91,575" },
      ],
      salesData: [
        { month: "Jan", sales: 1011240 },
        { month: "Feb", sales: 1601130 },
        { month: "Mar", sales: 1264050 },
        { month: "Apr", sales: 2106750 },
        { month: "May", sales: 1853940 },
        { month: "Jun", sales: 2528100 },
      ],
      categoryData: [
        { category: "Electronics", value: 30 },
        { category: "Clothing", value: 40 },
        { category: "Accessories", value: 20 },
        { category: "Home & Garden", value: 10 },
      ],
    };
  }
}

export const storage = new DatabaseStorage();
