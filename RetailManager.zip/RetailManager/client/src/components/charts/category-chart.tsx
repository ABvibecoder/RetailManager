import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from "recharts";

interface CategoryChartProps {
  data: Array<{ category: string; value: number }>;
}

const COLORS = [
  "hsl(var(--primary))",
  "#10B981",
  "#F59E0B", 
  "#8B5CF6"
];

export default function CategoryChart({ data }: CategoryChartProps) {
  return (
    <ResponsiveContainer width="100%" height={256}>
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          innerRadius={60}
          outerRadius={100}
          paddingAngle={2}
          dataKey="value"
        >
          {data.map((_, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  );
}
