import { Menu } from "lucide-react";
import { useApp } from "@/lib/context";

export default function MobileHeader() {
  const { setIsMobileSidebarOpen } = useApp();

  return (
    <header className="bg-white border-b border-gray-200 lg:hidden">
      <div className="flex items-center justify-between px-4 py-3">
        <button
          onClick={() => setIsMobileSidebarOpen(true)}
          className="text-gray-500 hover:text-gray-700"
        >
          <Menu className="h-6 w-6" />
        </button>
        <h1 className="text-lg font-semibold text-gray-900">RetailPro</h1>
        <div className="w-6" />
      </div>
    </header>
  );
}
