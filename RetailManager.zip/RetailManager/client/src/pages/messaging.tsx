import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { MessageCircle, Send, Users, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const individualMessageSchema = z.object({
  customerId: z.string().min(1, "Please select a customer"),
  content: z.string().min(1, "Message content is required"),
});

const bulkMessageSchema = z.object({
  group: z.string().min(1, "Please select a customer group"),
  content: z.string().min(1, "Message content is required"),
  confirmed: z.boolean().refine(val => val === true, "Please confirm sending the message"),
});

export default function Messaging() {
  const [activeTab, setActiveTab] = useState<"individual" | "bulk">("individual");
  const { toast } = useToast();

  const { data: customers = [] } = useQuery<any[]>({
    queryKey: ["/api/customers"],
  });

  const { data: messages = [] } = useQuery<any[]>({
    queryKey: ["/api/messages"],
  });

  const individualForm = useForm<z.infer<typeof individualMessageSchema>>({
    resolver: zodResolver(individualMessageSchema),
    defaultValues: {
      customerId: "",
      content: "",
    },
  });

  const bulkForm = useForm<z.infer<typeof bulkMessageSchema>>({
    resolver: zodResolver(bulkMessageSchema),
    defaultValues: {
      group: "",
      content: "",
      confirmed: false,
    },
  });

  const sendIndividualMutation = useMutation({
    mutationFn: (data: z.infer<typeof individualMessageSchema>) => {
      const customer = customers.find((c: any) => c.id === data.customerId);
      return apiRequest("POST", "/api/messages", {
        type: "individual",
        recipients: [customer?.phone || customer?.id],
        content: data.content,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      individualForm.reset();
      toast({ title: "Message sent successfully" });
    },
    onError: () => {
      toast({ title: "Failed to send message", variant: "destructive" });
    }
  });

  const sendBulkMutation = useMutation({
    mutationFn: (data: z.infer<typeof bulkMessageSchema>) => {
      // In a real implementation, this would filter customers based on the group
      const recipients = customers.map((c: any) => c.phone || c.id);
      return apiRequest("POST", "/api/messages", {
        type: "bulk",
        recipients,
        content: data.content,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      bulkForm.reset();
      toast({ title: "Bulk message sent successfully" });
    },
    onError: () => {
      toast({ title: "Failed to send bulk message", variant: "destructive" });
    }
  });

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "delivered": return "default";
      case "read": return "secondary";
      case "failed": return "destructive";
      default: return "outline";
    }
  };

  const formatTimestamp = (timestamp: string | Date) => {
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="p-4 lg:p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900">WhatsApp Messaging</h2>
        <p className="mt-1 text-sm text-gray-600">Send messages and manage customer communications</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Individual Messaging */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <MessageCircle className="mr-2 h-5 w-5" />
              Send Individual Message
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...individualForm}>
              <form onSubmit={individualForm.handleSubmit((data) => sendIndividualMutation.mutate(data))} className="space-y-4">
                <FormField
                  control={individualForm.control}
                  name="customerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Select Customer</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Choose a customer..." />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {customers.map((customer: any) => (
                            <SelectItem key={customer.id} value={customer.id}>
                              {customer.name} ({customer.phone})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={individualForm.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Message</FormLabel>
                      <FormControl>
                        <Textarea 
                          rows={4} 
                          placeholder="Type your message here..." 
                          {...field} 
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full bg-green-600 hover:bg-green-700"
                  disabled={sendIndividualMutation.isPending}
                >
                  <Send className="mr-2 h-4 w-4" />
                  {sendIndividualMutation.isPending ? "Sending..." : "Send Message"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Bulk Messaging */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="mr-2 h-5 w-5" />
              Send Bulk Message
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...bulkForm}>
              <form onSubmit={bulkForm.handleSubmit((data) => sendBulkMutation.mutate(data))} className="space-y-4">
                <FormField
                  control={bulkForm.control}
                  name="group"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer Group</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select group..." />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="all">All Customers ({customers.length})</SelectItem>
                          <SelectItem value="vip">VIP Customers</SelectItem>
                          <SelectItem value="recent">Recent Customers</SelectItem>
                          <SelectItem value="inactive">Inactive Customers</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={bulkForm.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Message</FormLabel>
                      <FormControl>
                        <Textarea 
                          rows={4} 
                          placeholder="Type your bulk message here..." 
                          {...field} 
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={bulkForm.control}
                  name="confirmed"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <Label>I confirm sending this message to selected customers</Label>
                      </div>
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full bg-green-600 hover:bg-green-700"
                  disabled={sendBulkMutation.isPending}
                >
                  <Send className="mr-2 h-4 w-4" />
                  {sendBulkMutation.isPending ? "Sending..." : "Send Bulk Message"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>

      {/* Message History */}
      <Card className="mt-8">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center">
              <Clock className="mr-2 h-5 w-5" />
              Message History
            </CardTitle>
            <div className="flex space-x-2">
              <Button 
                variant={activeTab === "individual" ? "default" : "outline"} 
                size="sm"
                onClick={() => setActiveTab("individual")}
              >
                Individual
              </Button>
              <Button 
                variant={activeTab === "bulk" ? "default" : "outline"} 
                size="sm"
                onClick={() => setActiveTab("bulk")}
              >
                Bulk
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {messages.length === 0 ? (
              <div className="text-center py-8">
                <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No messages sent yet</p>
                <p className="text-sm text-gray-400">Your message history will appear here</p>
              </div>
            ) : (
              messages
                .filter((message: any) => activeTab === "individual" ? message.type === "individual" : message.type === "bulk")
                .map((message: any) => (
                  <div key={message.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                          <MessageCircle className="h-4 w-4 text-green-600" />
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-gray-900">
                            {message.type === "bulk" ? "Bulk Message" : "Individual Message"}
                          </p>
                          <p className="text-sm text-gray-500">
                            {message.type === "bulk" 
                              ? `Sent to ${message.recipients.length} customers`
                              : "Sent to individual customer"
                            }
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-500">{formatTimestamp(message.sentAt)}</p>
                        <Badge variant={getStatusVariant(message.status)}>
                          {message.status.charAt(0).toUpperCase() + message.status.slice(1)}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-gray-700">{message.content}</p>
                  </div>
                ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
